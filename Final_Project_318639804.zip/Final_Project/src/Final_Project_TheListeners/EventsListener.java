package Final_Project_TheListeners;

public interface EventsListener {
	void fireActionCompleted();

	void fireActionFailed();

	void fireCountryEmpty();

	void fireCountrySame();

	void fireEndOlympicsFailed();
}
