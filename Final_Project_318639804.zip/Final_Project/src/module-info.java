module Final_Project {
	exports Program;
	requires javafx.graphics;
	requires javafx.controls;
	requires java.desktop;
}